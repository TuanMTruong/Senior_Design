# Image samples

The files are standard XBM (X11 Bitmap files); the format is a
straightforward C structure that can be included in the demo program.

The files are name includes the display size:

----------------------------------------------------------
Suffix         Width x Height
-----------    ----------------
\_1\_44.xbm    128 x 96

\_2\_0.xbm     200 x 96

\_2\_7.xbm     264 x 176
----------------------------------------------------------


----------------------------------------------------------
Name           Description
-----------    -----------------------------
aphrodite      Aphrodite of Rhodes statue

cat            Striped cat

saturn         Sixth planet and second largest planet in the Solar System

text\_hello    A small sample from the EMACS hello file

text\_image    Text sample

venus          Detail from The Birth of Venus by Botticelli
----------------------------------------------------------
